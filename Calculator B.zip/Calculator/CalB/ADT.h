#ifndef ADT_H_INCLUDED
#define ADT_H_INCLUDED

#include <iostream>
#include <string>
#include <math.h>

using namespace std;

// STACK
#define infos(S) ((S).infos)
#define infoIn(S) ((S).infoIn)
#define Top(S) ((S).Top)
#define TopIn(S) ((S).TopIn)
//QUEUE
#define nil NULL
#define infoq(P) (P)->infoq
#define next(P) (P)->next
#define head(Q) ((Q).head)
#define tail(Q) ((Q).tail)

//STACK
const int MAX = 25;

struct StackCh {
    char infos[MAX];
    int Top;
};

struct StackIn {
    int infoIn[MAX];
    int TopIn;
};

//QUEUE
typedef struct elmQueue *adrQ;

struct elmQueue {
    char infoq;
    adrQ next;
};

struct Queue{
    adrQ head;
    adrQ tail;
};

//STACK
void createStackChar(StackCh &S);           // Membuat Stack yang memuat data bertipe char
void createStackInt(StackIn &S);            // Membuat Stack yang memuat data bertipe integer
void pushStackChar(StackCh &S, char A);     //Memasukkan data bertipe char ke dalam stack
void pushStackInt(StackIn &S, int A);       //Memasukkan data bertipe integer ke dalam stack
char popStackChar(StackCh &S);              //Menghapus isi data bertipe char dari dalam stack
int popStackInt(StackIn &S);                //Menghapus isi data bertipe integer dari dalam stack
bool isFullChar(StackCh S);                 //Function untuk mengecek stack char full atau tidak
bool isFullInt(StackIn S);                  //Function untuk mengecek stack int full atau tidak
void PrintStack(StackIn S);                 //Procedure untuk mengeprint seluruh data dalam stack int
void PrintStackch(StackCh S);               //Procedure untuk mengeprint seluruh data dalam stack char

//QUEUE
void CreateQueue(Queue &Q);                 //Membuat Queue
adrQ NewElmntQueue(char x);                 //Membuat elemen yang berisi data bertipe char
void Enqueque(Queue &Q, adrQ P);            //Memasukkan data ke dalam queue
void DeleteAll(Queue &Q);                   //Menghapus seluruh elemen pada stack
void ShowQueue(Queue Q);                    //Menampilkan seluruh isi data queue

//Proses inti
bool IsOperator(char x);                    //Function untuk mengecek operator dari beberapa bagian dari string
int IsPriority(char x);                     //Function untuk mengecek prioritas masing-masing operator
void ToPostfix(Queue &Q, StackCh &S, char X);   // Procedure untuk merubah notasi infix menjadi postfix
int IsNumber(char x);                       //Function untuk mereturn angka
bool ValidNumber(char x);                   //Function untuk mengecek char berupa int
bool Validasi(string x);                    //Function untuk mengecek validasi inputan


#endif // ADT_H_INCLUDED
