#include "ADT.h"
#include <typeinfo>

int main()
{
    Queue Q;
    StackCh Sc;
    StackIn Si;

    //Mengcreate Stack dan Queue
    CreateQueue(Q);
    createStackChar(Sc);
    createStackInt(Si);
    pushStackChar(Sc, '(');         //Memasukkan tanda '(' untuk patokan iterasi

    cout << "==================SELAMAT DATANG DI KALKULATOR B=================="<<endl;
    cout << "=============MERUBAH NOTASI INFIX MENJADI NOTASI POSTFIX============="<<endl;

    char a = 'Y';
    string input;

    while (a == 'Y'){
        cout << "Input notasi infix: ";
        cin >> input;
        cout << endl;

        if (Validasi(input)){
            for (int i = 0; i < input.length(); i++){       //Perulangan untuk mengakses setiap char pada string sesuai panjang string
                ToPostfix(Q, Sc, input[i]);                 //Dan memasukkan ke dalam procedure untuk dicek lagi
            }
            if (Top(Sc) != 0){                              //Pengkondisian ini digunakan untuk mengecek isi stack apakah ada operator yang tersisa
                int b;
                b = Top(Sc);

                while (infos(Sc)[b] != '('){                //Jika benar maka akan diproses melalui perulangan ini untuk dikeluarkan sampai ketemu tanda '('
                    char X;
                    adrQ P;

                    X = popStackChar(Sc);
                    P = NewElmntQueue(X);
                    Enqueque(Q, P);
                    b--;
                }
            }
            cout << "Notasi Infix: " << input << endl;
            cout << "Notasi Postfix: ";
            ShowQueue(Q);

            int hasil;
            adrQ w = head(Q);
            while (w != nil){                       //Perulangan dan pengkondisiian ini digunakan untuk mengecek hasil aritmatika dari notasi postfix
                char D = infoq(w);
                if (ValidNumber(D)){
                    int N = IsNumber(D);
                    pushStackInt(Si, N);
                }else if (IsOperator(D)){
                    int Op1, Op2;
                    Op2 = popStackInt(Si);
                    Op1 = popStackInt(Si);

                    if (D == '+'){
                        hasil = Op1 + Op2;
                    }else if(D == '-'){
                        hasil = Op1 - Op2;
                    }else if(D == '*'){
                        hasil = Op1 * Op2;
                    }else if(D == '/'){
                        hasil = Op1 / Op2;
                    }else if (D == '^'){
                        hasil = pow(Op1, Op2);
                    }
                    pushStackInt(Si, hasil);
                }
                w = next(w);
            }
            cout << "Hasilnya= ";
            PrintStack(Si);
            cout << endl;
        }else {
            cout << "Inputan Tidak Valid" << endl;
        }
        popStackInt(Si);
        DeleteAll(Q);
        cout << "Mau Coba Lagi?(Y/N) :";
        cin >> a;
    }
    cout << endl;
    cout << "ANDA TELAH KELUAR DARI PROGRAM" <<endl;
    cout << "TERIMAKASIH SUDAH MENCOBA KALKULATOR B :)" << endl;
}
