#include "ADT.h"

//STACK
void createStackChar(StackCh &S){   // Membuat Stack yang memuat data bertipe char
    Top(S) = 0;
}
void createStackInt(StackIn &S){     // Membuat Stack yang memuat data bertipe integer
    TopIn(S) = 0;
}
void pushStackChar(StackCh &S, char A){ //Memasukkan data bertipe char ke dalam stack
    if (isFullChar(S) == false){
        Top(S) = Top(S) + 1;
        infos(S)[Top(S)] = A;
    }else {
        cout << "Stack Penuh" << endl;
    }
}
void pushStackInt(StackIn &S, int A){       //Memasukkan data bertipe integer ke dalam stack
    if (isFullInt(S) == false){
        TopIn(S) = TopIn(S) + 1;
        infoIn(S)[TopIn(S)] = A;
    }else {
        cout << "Stack Penuh " << endl;
    }
}
char popStackChar(StackCh &S){              //Menghapus isi data bertipe char dari dalam stack
    char P;

    P = infos(S)[Top(S)];
    Top(S) = Top(S) - 1;

    return P;
}
int popStackInt(StackIn &S){                //Menghapus isi data bertipe integer dari dalam stack
    int I;

    I = infoIn(S)[TopIn(S)];
    TopIn(S) = TopIn(S) - 1;

    return I;
}
bool isFullChar(StackCh S){                 //Function untuk mengecek stack char full atau tidak
    if (Top(S) == MAX){
        return true;
    }else {
        return false;
    }
}
bool isFullInt(StackIn S){                  //Function untuk mengecek stack int full atau tidak
    if (TopIn(S) == MAX){
        return true;
    }else {
        return false;
    }
}

void PrintStack(StackIn S){                     //Procedure untuk mengeprint seluruh data dalam stack int
     for (int x = TopIn(S); x != 0; x--){
        cout << infoIn(S)[x];
    }
    cout << endl;
}
void PrintStackch(StackCh S){                   //Procedure untuk mengeprint seluruh data dalam stack char
    for (int x = Top(S); x != 0; x--){
        cout << infos(S)[x];
    }
    cout << endl;
}


//QUEUE
void CreateQueue(Queue &Q){         //Membuat Queue
    head(Q) = nil;
    tail(Q) = nil;
}
adrQ NewElmntQueue(char x){         //Membuat elemen yang berisi data bertipe char
    adrQ P = new elmQueue;

    infoq(P) = x;
    next(P) = nil;

    return P;
}
void Enqueque(Queue &Q, adrQ P){    //Memasukkan data ke dalam queue
    if (head(Q) == nil && tail(Q) == nil){
        head(Q) = P;
        tail(Q) = P;
    }else {
        next(tail(Q)) = P;
        tail(Q) = P;
    }
}

void DeleteAll(Queue &Q){           //Menghapus seluruh elemen pada stack
    while (head(Q) != nil){
        adrQ P = head(Q);
        head(Q) = next(P);
        delete P;
    }
    tail(Q) = nil;
}

void ShowQueue(Queue Q){            //Menampilkan seluruh isi data queue
    adrQ P = head(Q);

    if (head(Q) == nil && tail(Q) == nil){
        cout << "Queue Kosong" << endl;
    }else {
        while (next(P) != nil){
            cout << infoq(P);
            P = next(P);
        }
        cout << infoq(P);
        cout << endl;
    }
}


//Proses inti
bool IsOperator(char x){            //Function untuk mengecek operator dari beberapa bagian dari string
    if (x == '*' || x == '/' || x == '+' || x == '-' || x == '^' || x == '(' || x == ')'){
        return true;
    }else {
        return false;
    }
}
int IsPriority(char x){            //Function mengecek prioritas operator
    if (x == '^'){
        return 3;
    }else if (x == '*' || x == '/'){
        return 2;
    }else if (x == '+' || x == '-') {
        return 1;
    }
}
void ToPostfix(Queue &Q, StackCh &S, char X){       // Function untuk merubah notasi infix ke postfix
    adrQ P;
    int a;
    char A;

    if (Top(S) == 0 && IsOperator(X)){
            pushStackChar(S, X);
       }else if (Top(S) != 0 && IsOperator(X)){
           if (IsPriority(infos(S)[Top(S)]) < IsPriority(X) && X != ')'){
                pushStackChar(S, X);
           }else if (infos(S)[Top(S)] == '('){
                pushStackChar(S, X);
           }else if (IsPriority(infos(S)[Top(S)]) > IsPriority(X)){
               A = popStackChar(S);
               P = NewElmntQueue(A);
               Enqueque(Q, P);
               int g = 1 ;
               while (g > 0){
                    if (IsPriority(infos(S)[Top(S)]) > IsPriority(X) && infos(S)[Top(S)] != '('){
                        A = popStackChar(S);
                        P = NewElmntQueue(A);
                        Enqueque(Q, P);
                        g++;
                    }else {
                        g = 0;
                    }
               }
               pushStackChar(S, X);
           }else if (X == ')'){
               a = Top(S);
               while (infos(S)[a] != '('){
                    A = popStackChar(S);
                    P = NewElmntQueue(A);
                    Enqueque(Q, P);
                    a--;
                }
                A = popStackChar(S);
           }else if (IsPriority(infos(S)[Top(S)]) == IsPriority(X)){
               A = popStackChar(S);
               P = NewElmntQueue(A);
               Enqueque(Q, P);
               pushStackChar(S, X);
           }
       }else {
           P = NewElmntQueue(X);
           Enqueque(Q, P);
        }
}

int IsNumber(char x){               //Function untuk mereturn angka
    if (x == '0'){
        return 0;
    }else if (x == '1'){
        return 1;
    }else if (x == '2'){
        return 2;
    }else if (x == '3'){
        return 3;
    }else if (x == '4'){
        return 4;
    }else if (x == '5'){
        return 5;
    }else if (x == '6'){
        return 6;
    }else if (x == '7'){
        return 7;
    }else if (x == '8'){
        return 8;
    }else if (x == '9'){
        return 9;
    }
}

bool ValidNumber(char x){               //Function untuk mengecek char berupa int
    if (x == '0'){
        return true;
    }else if (x == '1'){
        return true;
    }else if (x == '2'){
        return true;
    }else if (x == '3'){
        return true;
    }else if (x == '4'){
        return true;
    }else if (x == '5'){
        return true;
    }else if (x == '6'){
        return true;
    }else if (x == '7'){
        return true;
    }else if (x == '8'){
        return true;
    }else if (x == '9'){
        return true;
    }else {
        return false;
    }
}

bool Validasi(string x){                 //Function untuk mengecek validasi inputan
    int Operand = 0;
    int Operator = 0;
    int Brackets = 0;


    for (int i = 0; i < x.length(); i++){
        if (IsOperator(x[i]) || ValidNumber(x[i])){
            if (x[i] == '('){
                Brackets += 1;
            }else if (x[i] == ')'){
                Brackets -= 1;
            }else if (ValidNumber(x[i])){
                Operand += 1;
            }else if (IsOperator(x[i])){
                Operator += 1;
            }
        }else {
            return false;
        }
    }
    if (Brackets == 0 && Operator == Operand-1 && Operator > 0 && Operand > 0 && x[0] != '^' && x[0] == '*' && x[0] != '/' && x[0] != '+' && x[0] != '-' ){
        return true;
    }else{
        return false;
    }
}


